#!/bin/bash
# test.sh — Quick test script for the notification server
# Usage: ./test.sh [host] [port]

HOST="${1:-localhost}"
PORT="${2:-8080}"
BASE="http://${HOST}:${PORT}"

echo "=== Notification Server Test ==="
echo "Target: $BASE"
echo ""

# ── Health check ──────────────────────────────────────────────────────────────
echo "1. Health check:"
curl -s "${BASE}/health" | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

# ── Metrics ───────────────────────────────────────────────────────────────────
echo "2. Metrics:"
curl -s "${BASE}/metrics" | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

# ── Active connections ────────────────────────────────────────────────────────
echo "3. Active connections:"
curl -s "${BASE}/connections" | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

# ── Send notification ─────────────────────────────────────────────────────────
echo "4. Send notification to user 'user-123':"
curl -s -X POST "${BASE}/notify" \
    -H "Content-Type: application/json" \
    -d '{"user_id": "user-123", "message": "Your order has shipped!", "type": "order"}' \
    | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

echo "5. Send notification to user 'alice':"
curl -s -X POST "${BASE}/notify" \
    -H "Content-Type: application/json" \
    -d '{"user_id": "alice", "message": "Welcome to the platform!", "type": "info"}' \
    | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

echo "6. Bad request (missing fields):"
curl -s -X POST "${BASE}/notify" \
    -H "Content-Type: application/json" \
    -d '{"user_id": "alice"}' \
    | python3 -m json.tool 2>/dev/null || echo "FAILED"
echo ""

echo ""
echo "=== WebSocket Test ==="
echo "Connect a WebSocket client to:"
echo "  ws://${HOST}:${PORT}/ws?user_id=user-123"
echo ""
echo "Then POST to /notify with user_id=user-123 to see real-time delivery."
echo ""
echo "You can use wscat:"
echo "  npm install -g wscat"
echo "  wscat -c 'ws://${HOST}:${PORT}/ws?user_id=user-123'"
echo ""
