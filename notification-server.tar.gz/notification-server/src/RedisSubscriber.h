#pragma once

#include <string>
#include <thread>
#include <atomic>
#include <functional>
#include <memory>
#include <sw/redis++/redis++.h>

// Runs Redis SUBSCRIBE in a background thread and calls the handler
// for each message received on the subscribed channel.
class RedisSubscriber {
public:
    using MessageHandler = std::function<void(const std::string& message)>;

    RedisSubscriber(const std::string& redis_url,
                    const std::string& channel,
                    MessageHandler handler);

    ~RedisSubscriber();

    void start();
    void stop();

private:
    void run();

    std::string     redis_url_;
    std::string     channel_;
    MessageHandler  handler_;
    std::atomic<bool> running_{false};
    std::thread     thread_;
};
