#include "RedisSubscriber.h"
#include <iostream>
#include <chrono>

RedisSubscriber::RedisSubscriber(const std::string& redis_url,
                                 const std::string& channel,
                                 MessageHandler handler)
    : redis_url_(redis_url), channel_(channel), handler_(std::move(handler)) {}

RedisSubscriber::~RedisSubscriber() {
    stop();
}

void RedisSubscriber::start() {
    running_ = true;
    thread_ = std::thread(&RedisSubscriber::run, this);
}

void RedisSubscriber::stop() {
    running_ = false;
    if (thread_.joinable()) {
        thread_.join();
    }
}

void RedisSubscriber::run() {
    while (running_) {
        try {
            sw::redis::Redis redis(redis_url_);
            auto sub = redis.subscriber();

            sub.on_message([this](std::string /*channel*/, std::string message) {
                if (handler_) {
                    handler_(message);
                }
            });

            sub.subscribe(channel_);
            std::cout << "[RedisSubscriber] Subscribed to channel: " << channel_ << "\n";

            // consume() blocks until connection drops or error
            while (running_) {
                try {
                    sub.consume();
                } catch (const sw::redis::TimeoutError&) {
                    // Normal timeout, keep looping
                } catch (const std::exception& e) {
                    std::cerr << "[RedisSubscriber] consume() error: " << e.what() << "\n";
                    break; // reconnect
                }
            }
        } catch (const std::exception& e) {
            std::cerr << "[RedisSubscriber] Connection error: " << e.what()
                      << " — retrying in 2s\n";
            std::this_thread::sleep_for(std::chrono::seconds(2));
        }
    }

    std::cout << "[RedisSubscriber] Stopped.\n";
}
