#pragma once

#include <atomic>
#include <string>
#include <chrono>

class MetricsCollector {
public:
    static MetricsCollector& instance() {
        static MetricsCollector inst;
        return inst;
    }

    void increment_messages_sent()   { messages_sent_++; }
    void increment_failed_deliveries(){ failed_deliveries_++; }
    void increment_redis_published() { redis_published_++; }
    void increment_redis_received()  { redis_received_++; }

    // Returns JSON string of all metrics
    std::string to_json() const;

    // Uptime in seconds
    long uptime_seconds() const;

private:
    MetricsCollector();

    std::atomic<uint64_t> messages_sent_{0};
    std::atomic<uint64_t> failed_deliveries_{0};
    std::atomic<uint64_t> redis_published_{0};
    std::atomic<uint64_t> redis_received_{0};
    std::chrono::steady_clock::time_point start_time_;
};
