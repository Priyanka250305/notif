#pragma once

#include <string>
#include <memory>
#include <unordered_set>
#include <mutex>
#include <sw/redis++/redis++.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Represents a single notification
struct Notification {
    std::string id;        // unique notification ID (for deduplication)
    std::string user_id;
    std::string message;
    std::string type;      // e.g. "order", "alert", "info"
    long long   timestamp;

    static Notification from_json(const json& j);
    json to_json() const;
};

class NotificationService {
public:
    NotificationService(std::shared_ptr<sw::redis::Redis> redis,
                        const std::string& channel = "notifications");

    // Called by POST /notify — publishes to Redis
    // Returns false if request is invalid
    bool publish(const json& payload, std::string& error_msg);

    // Called by Redis subscriber — delivers locally if user connected
    void deliver(const std::string& raw_message);

    const std::string& channel() const { return channel_; }

private:
    bool already_processed(const std::string& notification_id);
    void mark_processed(const std::string& notification_id);

    std::shared_ptr<sw::redis::Redis> redis_;
    std::string channel_;

    // In-memory dedup set (for single-instance; Redis handles multi-instance)
    mutable std::mutex dedup_mutex_;
    std::unordered_set<std::string> processed_ids_;
};
