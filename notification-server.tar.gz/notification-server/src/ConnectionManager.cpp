#include "ConnectionManager.h"
#include <iostream>

void ConnectionManager::add(const std::string& user_id, WebSocketConnection* conn) {
    std::lock_guard<std::mutex> lock(mutex_);
    connections_[user_id] = conn;
    std::cout << "[ConnectionManager] User connected: " << user_id
              << " | Total: " << connections_.size() << "\n";
}

void ConnectionManager::remove(const std::string& user_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = connections_.find(user_id);
    if (it != connections_.end()) {
        connections_.erase(it);
        std::cout << "[ConnectionManager] User disconnected: " << user_id
                  << " | Total: " << connections_.size() << "\n";
    }
}

bool ConnectionManager::send(const std::string& user_id, const std::string& message) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = connections_.find(user_id);
    if (it != connections_.end()) {
        try {
            it->second->send_text(message);
            total_sent_++;
            return true;
        } catch (const std::exception& e) {
            std::cerr << "[ConnectionManager] Send failed for " << user_id
                      << ": " << e.what() << "\n";
            total_failed_++;
            return false;
        }
    }
    return false;
}

void ConnectionManager::broadcast(const std::string& message) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [user_id, conn] : connections_) {
        try {
            conn->send_text(message);
            total_sent_++;
        } catch (const std::exception& e) {
            std::cerr << "[ConnectionManager] Broadcast failed for " << user_id
                      << ": " << e.what() << "\n";
            total_failed_++;
        }
    }
}

bool ConnectionManager::is_connected(const std::string& user_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return connections_.find(user_id) != connections_.end();
}

size_t ConnectionManager::connection_count() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return connections_.size();
}

std::vector<std::string> ConnectionManager::connected_users() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> users;
    users.reserve(connections_.size());
    for (const auto& [user_id, _] : connections_) {
        users.push_back(user_id);
    }
    return users;
}
