#include "MetricsCollector.h"
#include "ConnectionManager.h"
#include <sstream>

MetricsCollector::MetricsCollector()
    : start_time_(std::chrono::steady_clock::now()) {}

long MetricsCollector::uptime_seconds() const {
    auto now = std::chrono::steady_clock::now();
    return std::chrono::duration_cast<std::chrono::seconds>(now - start_time_).count();
}

std::string MetricsCollector::to_json() const {
    auto& cm = ConnectionManager::instance();
    std::ostringstream oss;
    oss << "{\n"
        << "  \"active_connections\": " << cm.connection_count() << ",\n"
        << "  \"messages_sent\": "      << messages_sent_.load()      << ",\n"
        << "  \"failed_deliveries\": "  << failed_deliveries_.load()  << ",\n"
        << "  \"redis_published\": "    << redis_published_.load()    << ",\n"
        << "  \"redis_received\": "     << redis_received_.load()     << ",\n"
        << "  \"uptime_seconds\": "     << uptime_seconds()           << "\n"
        << "}";
    return oss.str();
}
